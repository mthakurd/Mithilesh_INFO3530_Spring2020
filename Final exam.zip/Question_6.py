import math

class Point:
  def __init__(self,x=0,y=0):
    self.x = x
    self.y = y

  def __str__(self):
    return "The point is ({0},{1})".format(self.x,self.y)

  def __add__(self, other):
    p3_x = self.x + other.x
    p3_y = self.y + other.y
    p3 = Point(p3_x, p3_y)
    return p3



if __name__ == "__main__":


    p1 = Point(1,3)
    p2 = Point(3,4)
    print(p1 + p2)




    #solution 2

# import math
#
#
# class Point:
#     def __init__(self, x=0, y=0):
#         self.x = x
#         self.y = y
#
#     def __str__(self):
#         return "The point is ({0},{1})".format(self.x, self.y)
#
#     def distance(A, B):
#         p3_x = A.x + B.x
#         p3_y = A.y + B.y
#         p3 = Point(p3_x, p3_y)
#         return p3
#
# if __name__ == "__main__":
#     p1 = Point(1,3)
#     p2 = Point(3,4)
#     print(distance(p1, p2))