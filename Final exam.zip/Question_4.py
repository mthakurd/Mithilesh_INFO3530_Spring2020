import numpy as np

def print_matrix(my_matrix):
    my_array = np.asarray(my_matrix)
    for item in my_array:
        for j in range(len(item)):
            if item[j] > 20:
                item[j] = 0
    with open('result.txt', 'w') as f:
        f.write(str(my_array))

if __name__ == "__main__":
    my_matrix = [[23,43,12],[32,12,52],[15,35,52],[19,28,56]]
    print_matrix(my_matrix)