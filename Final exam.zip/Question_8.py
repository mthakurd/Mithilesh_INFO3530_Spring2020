import pymysql

def avgLifeExpectancy():
    db = pymysql.connect("localhost","root","Alfa2020","world")
    dbcursor = db.cursor()

    sql = "SELECT AVG(LifeExpectancy), continent FROM world.country group by Continent"

    dbcursor.execute(sql)
    results = dbcursor.fetchall()

    print("avglife  |  continent")
    for item in results:
        print(str(item[0]) + '  |  ' + item[1])

    dbcursor.close()
    db.close()

if __name__ == "__main__":
    avgLifeExpectancy()