def print_string(s):
    print(s)

if __name__ == "__main__":
    s = input("please input a string: ")
    print_string(s)