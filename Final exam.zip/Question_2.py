def sumofevendigit():

    sum = 0
    for i in range(1,1001):
        if i % 2 == 0:
            sum = sum + i


    print(sum)

if __name__ == "__main__":
    sumofevendigit()


