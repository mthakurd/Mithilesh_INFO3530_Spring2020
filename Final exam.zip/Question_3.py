mul = 1

def multiply(lst, depth):
    global mul
    for item in lst:
        if isinstance(item, int):
            mul *= item
        elif isinstance(item, list):
            multiply(item, depth-1)
    return mul



if __name__ == "__main__":
    lst = [12,10,3,2,[6,[7,8,9],19,21],21]
    result = multiply(lst, 3)
    print(result)