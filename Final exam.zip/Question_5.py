def count_freq(num_list):
    new_list = []
    result = {}
    for num in num_list:
        if num not in new_list:
            new_list.append(num)
    for number in num_list:
        if number not in result:
            result[number] = 1
        else:
            result[number] += 1
    for item in result:
        print(item, result[item])


if __name__ == "__main__":
    numbers = [1,3,2,4,2,3,2,2,3,2,2,4,2,32,3,2,4,2,3,5,3,2,4,2,2,4,2,2,4,2,2,3,1,3,2,3]
    count_freq(numbers)