import pandas as pd

df = pd.read_excel ('catering_sale_all.xls')
data = pd.DataFrame(df)

data_dict = {0: 'exit', 1: 'chicken feet', 2: 'steamed dumplings', 3: 'ribs', 4: 'full chicken', 5: 'stuffed bun', 6: 'flowering cabbage',
             7: 'doufu', 8: 'chive dumplings', 9: 'pudding', 10: 'original cabbage'}

while True:
    for item in data_dict:
        print(item, data_dict[item])
    choice = int(input('please input number in the list:'))
    if choice == 0:
        break
    else:
        food = data_dict[choice]
        print('total sale of ' + food + ' is ' + str(data[food].sum()))