import pandas as pd
import matplotlib.pyplot as plt

def saveData(input_csv):
    df = pd.read_csv(input_csv)
    data = pd.DataFrame(df)
    column_names = []
    for i in range(len(data.columns)):
        column_names.append(data.columns[i])
    return data, column_names[2:]

def retrieveInfo(info, year):
    for item in info.iterrows():
        if int(item[1][1]) == year:
            return item[1]

def displayResult(energy_info, column_names):
    energy_values = []
    for item in energy_info:
        energy_values.append(item)
    energy_values = energy_values[2:]

    plt.ylim(0, 40)
    plt.bar(column_names, energy_values)
    plt.xticks(rotation=-25, fontsize='x-small')
    plt.subplots_adjust(bottom=0.15)
    plt.show()


if __name__ == "__main__":
    info, column_names = saveData('energy-production.csv')
    year = int(input('Please input a year between 1973 and 2014:'))
    energy_info = retrieveInfo(info, year)
    displayResult(energy_info, column_names)