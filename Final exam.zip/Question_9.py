import pymysql
from pylab import *

def populationPercentage():
    db = pymysql.connect("localhost","root","Alfa2020","world")
    dbcursor = db.cursor()

    sql = "SELECT continent, sum(Population), continent FROM world.country group by Continent"

    dbcursor.execute(sql)
    results = dbcursor.fetchall()
    x_labels = []
    y_values = []
    for item in results:
        x_labels.append(item[0])
        y_values.append(item[1])
    dbcursor.close()
    db.close()
    return x_labels, y_values

def plot_result(x_labels, y_values):
    figure(1, figsize=(6, 6))
    explode = (0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1)
    pie(y_values,explode=explode,labels=x_labels,autopct='%1.1f%%',startangle=100)

    title('population by continent')
    show()

if __name__ == "__main__":
    x_labels, y_values = populationPercentage()
    plot_result(x_labels, y_values)